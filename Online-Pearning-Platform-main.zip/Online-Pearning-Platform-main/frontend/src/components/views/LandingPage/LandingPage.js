import React, { useEffect, useState } from 'react'
import { Icon, Col, Card, Row } from 'antd';
import logo from "./img/im1.jpg";

function LandingPage() {

    return (
        <div style={{ width: '75%', margin: '6rem auto' }}>
            <div style={{ textAlign: 'center' }}>
                <h2>  WELCOME TO ENCRYPTOPOLIS  <Icon type="smile" />   </h2>
                <img src={logo} alt="kingdom logo" width="1050" height="450" />
            </div>
        </div>
    )
}

export default LandingPage
