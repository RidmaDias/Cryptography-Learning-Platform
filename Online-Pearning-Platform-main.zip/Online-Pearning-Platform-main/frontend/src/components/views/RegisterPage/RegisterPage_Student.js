import React, {useState} from "react";
import {Radio } from "antd";
import StudentReg from "./Sections/StudentRegPage";

function RegisterPage_Student(props) {

    const [regType,setRegType] = useState(0);

    const onChange = e => {
        console.log('radio checked', e.target.value);
        setRegType(e.target.value);
    };

    return (
        <div className="app" style={{  margin: '6rem auto' }}>
            <h2>Sign Up</h2>
            <Radio.Group
                onChange={onChange}
                optionType="button"
                defaultValue="0"
                buttonStyle="solid"
            >
                <Radio.Button value="0">Student</Radio.Button>
            </Radio.Group>

            { regType=="0"  ?
                <><br/>
                    <StudentReg/>
                </>

                : null }
        </div>
    );
};

export default RegisterPage_Student
