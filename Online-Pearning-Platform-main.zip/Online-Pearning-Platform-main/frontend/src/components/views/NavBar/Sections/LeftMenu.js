import React from 'react';
import { Menu } from 'antd';
import '../Sections/Navbar.css';
import { withRouter } from 'react-router-dom';
import { useSelector } from "react-redux";

const SubMenu = Menu.SubMenu;

function LeftMenu(props) {

  const user = useSelector(state => state.user)

  if (user.userData && !user.userData.isAuth) {
    return (
        //For Not Logged in user
        <Menu mode={props.mode}>
          <Menu.Item className="leftbtn" key="mail">
            <a  href="/">Home</a>
          </Menu.Item>

        </Menu>
    )
  } else if(user.userData && user.userData.isAdmin) {
    return (
        //For Admin
        <Menu mode={props.mode}>
            <Menu.Item className="leftbtn" key="mail">
                <a  href="/">Home</a>
            </Menu.Item>

            <SubMenu className="leftbtn" key="exam" title="Lessions">
            <Menu.Item key="results">
                <a href="/viewAllContent">Lession List</a>
            </Menu.Item>
            <Menu.Item key="viewExam">
                <a href="/createContent">Create Lession</a>
            </Menu.Item>
        </SubMenu>

      
        </Menu>
    )
  } else if(user.userData && user.userData.isStudent) {
    return (
        //For Student
        <Menu mode={props.mode}>

          <Menu.Item className="leftbtn" key="mail">
            <a  href="/stuHome">Start</a>
          </Menu.Item>

          <SubMenu className="leftbtn" key="exam" title="Lessions">
            <Menu.Item key="results">
                <a href="/bigginer">Bigginer</a>
            </Menu.Item>
            <Menu.Item key="viewExam">
                <a href="/interme">Intermediate</a>
            </Menu.Item>
            <Menu.Item key="viewExam">
                <a href="/advan">Advanced</a>
            </Menu.Item>
        </SubMenu>
            
        </Menu>


    )
  } else {
    return (
        //for Lecturer
        <Menu mode={props.mode}>
          <Menu.Item className="leftbtn" key="mail">
            <a  href="/">Home</a>
          </Menu.Item>

        <SubMenu className="leftbtn" key="exam" title="Lessions">
            <Menu.Item key="results">
                <a href="/viewAllContent">Lession List</a>
            </Menu.Item>
            <Menu.Item key="viewExam">
                <a href="/createContent">Create Lession</a>
            </Menu.Item>
        </SubMenu>

            <SubMenu className="leftbtn" key="subj" title="My courses">
              <Menu.Item key="results">
                 <a href="/addAtte">Level 1</a>
              </Menu.Item>
              <Menu.Item key="results">
                 <a href="/updateContent">Level 2</a>
              </Menu.Item>
            </SubMenu> 
                
        </Menu>
    )
  }
}

export default withRouter(LeftMenu);