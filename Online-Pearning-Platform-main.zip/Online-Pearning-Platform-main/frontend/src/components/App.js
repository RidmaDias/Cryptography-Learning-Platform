import React, { Suspense } from 'react';
import { Route, Switch } from "react-router-dom";
import Auth from "../hoc/auth";
// pages for this product
import LandingPage from "./views/LandingPage/LandingPage.js";
import LoginPage from "./views/LoginPage/LoginPage.js";
import RegisterPage from "./views/RegisterPage/RegisterPage";

import NavBar from "./views/NavBar/NavBar";
import Footer from "./views/Footer/Footer"
import UserDetailsPage from "./views/UserDetailsPage/UserDetailsPage";
import UserDetailsUpdatePage from "./views/UserDetailsUpdatePage/UserDetailsUpdatePage";

import Content_Create from './Content/Content_Create';
import Content_Update from './Content/Content_Update';
import Content_ViewList from './Content/Content_ViewList';
import Student_Home from './Content/Student_Home';
import Content_Bigginer from './Content/Content_Bigginer';
import Content_Intermediate from './Content/Content_Intermediate';
import Content_Advanced from './Content/Content_Advanced';
import RegisterPage_Student from "./views/RegisterPage/RegisterPage_Student";


function App() {
  return (
    <Suspense fallback={(<div>Loading...</div>)}>
      <NavBar />
      <div style={{ paddingTop: '75px', minHeight: 'calc(100vh - 80px)' }}>
        <Switch>
          <Route exact path="/" component={Auth(LandingPage, null)} />
          <Route exact path="/login" component={Auth(LoginPage, false)} />
          <Route exact path="/register" component={Auth(RegisterPage, true)} />
          <Route exact path="/user" component={UserDetailsPage} />
          <Route exact path="/updateUserInfo" component={UserDetailsUpdatePage} />
          <Route exact path="/user" component={Auth(UserDetailsPage, true)} />
          <Route exact path="/updateUserInfo" component={Auth(UserDetailsUpdatePage, true)} />


          <Route exact path="/createContent" component={Auth(Content_Create, true)} />
          <Route exact path="/updateContent/:id" component={Auth(Content_Update, true)} />
          <Route exact path="/viewAllContent" component={Auth(Content_ViewList, true)} />
          <Route exact path="/stuHome" component={Auth(Student_Home, true)} />
          <Route exact path="/bigginer" component={Auth(Content_Bigginer, true)} />
          <Route exact path="/interme" component={Auth(Content_Intermediate, true)} />
          <Route exact path="/advan" component={Auth(Content_Advanced, true)} />
          <Route exact path="/regStu" component={Auth(RegisterPage_Student, false)} />
          
        </Switch>
      </div>
      <Footer />
    </Suspense>
  );
}

export default App;
