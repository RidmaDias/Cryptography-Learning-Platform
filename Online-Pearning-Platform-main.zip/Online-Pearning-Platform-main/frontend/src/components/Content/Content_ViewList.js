import React, { useState, useEffect}  from 'react';
import axios from 'axios';
import { useParams, useHistory } from 'react-router-dom';
import './Content.css'
import { Link } from 'react-router-dom';

export default function Content_ViewList() {

    /*const {id} = useParams("");
    const history = useHistory();
    const [noticeList, setNoticeList] = useState([]);
    const [sessionList, setSessionList] = useState([]);*/

    const [bigList, setBigList] = useState([]);
    const [interList, setInterList] = useState([]);
    const [advList, setAdvList] = useState([]);

    const [userRouter, setUserRouter] = useState([]);

    useEffect(() => {
        const getDetailsList = async() => {
            try {
                const BigiResults = await axios.get(`http://localhost:5001/content/getBigginer`)
                setBigList(BigiResults.data);
                const InterResults = await axios.get(`http://localhost:5001/content/getIntermediate`)
                setInterList(InterResults.data);
                const AdvResults = await axios.get(`http://localhost:5001/content/getAdvanced`)
                setAdvList(AdvResults.data);
            } catch(err) {
                console.log(err);
            }
        }
        getDetailsList()
    },[]);

    const deleteDetail = async (ids) => {
        try {
            const res = await axios.delete(`http://localhost:5001/content/delete/${ids}`)
            alert("Successfully Deteted");
        } catch (err) {
            alert("Failed to delete");
            console.log(err);
        }
    }

    return(
        <div>

            <br/> <br/> <br/> <br/>

            <div className='viewTags'>
                <u><b><h3 className=" fw-bolder mb-4">Bigginers</h3></b></u>
            </div>

            <div className='tablePadding'>
                <table className="table ">
                    <thead className='tableHeader'>
                    <tr  key={"1"}>
                        <th> Introduction </th>
                        <th> Topic </th>
                        <th> Description </th>
                        <th> Question </th>
                        <th> Answer </th>
                        <th> Action </th>
                    </tr>
                    </thead>

                    <tbody className='table-group-divider'>
                    {
                        bigList.map((bigginer, id) => (
                            <tr key={id}>
                                <td>{bigginer.introduction}</td>
                                <td>{bigginer.topic1}</td>
                                <td>{bigginer.topic1des}</td>
                                <td>{bigginer.topic1quize}</td>
                                <td>{bigginer.topic1answ}</td>
                                
                                <td>
                                    <Link to={`/updateContent/${bigginer._id}`}><button className='buttonUpdate'>Update</button></Link>
                                    <Link onClick={() => {deleteDetail(bigginer._id);  window.location.reload()}}><button className='buttonDelete'>Delete</button></Link>
                                </td>
                            </tr>
                        ))
                    }
                    </tbody>
                </table>
            </div>

            <br/><br/><br/><br/>




            <div className='viewTags'>
                <u><b><h3 className=" fw-bolder mb-4">Intermediate</h3></b></u>
            </div>

            <div className='tablePadding'>
                <table className="table ">
                    <thead className='tableHeader'>
                    <tr  key={"1"}>
                        <th> Introduction </th>
                        <th> Topic </th>
                        <th> Description </th>
                        <th> Question </th>
                        <th> Answer </th>
                        <th> Action </th>
                    </tr>
                    </thead>

                    <tbody className='table-group-divider'>
                    {
                        interList.map((intermide, id) => (
                            <tr key={id}>
                                <td>{intermide.introduction}</td>
                                <td>{intermide.topic1}</td>
                                <td>{intermide.topic1des}</td>
                                <td>{intermide.topic1quize}</td>
                                <td>{intermide.topic1answ}</td>
                                
                                <td>
                                    <Link to={`/updateContent/${intermide._id}`}><button className='buttonUpdate'>Update</button></Link>
                                    <Link onClick={() => {deleteDetail(intermide._id);  window.location.reload()}}><button className='buttonDelete'>Delete</button></Link>
                                </td>
                            </tr>
                        ))
                    }
                    </tbody>
                </table>
            </div>


            
            <br/><br/><br/><br/>

            <div className='viewTags'>
                <u><b><h3 className=" fw-bolder mb-4">Advanced</h3></b></u>
            </div>

            <div className='tablePadding'>
                <table className="table ">
                    <thead className='tableHeader'>
                    <tr  key={"1"}>
                        <th> Introduction </th>
                        <th> Topic </th>
                        <th> Description </th>
                        <th> Question </th>
                        <th> Answer </th>
                        <th> Action </th>
                    </tr>
                    </thead>

                    <tbody className='table-group-divider'>
                    {
                        advList.map((advan, id) => (
                            <tr key={id}>
                                <td>{advan.introduction}</td>
                                <td>{advan.topic1}</td>
                                <td>{advan.topic1des}</td>
                                <td>{advan.topic1quize}</td>
                                <td>{advan.topic1answ}</td>
                                
                                <td>
                                    <Link to={`/updateContent/${advan._id}`}><button className='buttonUpdate'>Update</button></Link>
                                    <Link onClick={() => {deleteDetail(advan._id);  window.location.reload()}}><button className='buttonDelete'>Delete</button></Link>
                                </td>
                            </tr>
                        ))
                    }
                    </tbody>
                </table>
            </div>

        </div>
    )

}
