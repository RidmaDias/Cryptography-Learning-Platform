import React, { useState, useEffect}  from 'react';
import axios from 'axios';
import {useParams} from 'react-router-dom';
//import './NoticeSession.css';

export default function Content_Update(props) {

    const {id} = useParams("");   

    const [content, setContent] = useState({
        category:"", introduction:"", 
        topic1:"", topic1des:"", topic1quize:"", topic1answ:""
        /*topic2:"", topic2des:"", topic2quize:"", topic2answ:"",
        topic3:"", topic3des:"", topic3quize:"", topic3answ:""*/
    });

    const resetForm = () => {
        setContent({category:"", introduction:"", 
        topic1:"", topic1des:"", topic1quize:"", topic1answ:""
        /*topic2:"", topic2des:"", topic2quize:"", topic2answ:"",
        topic3:"", topic3des:"", topic3quize:"", topic3answ:""*/
    })}

    const onChange = e => {
        setContent({ ...content, [e.target.name]: e.target.value });
    }

    useEffect(() => {
        const getDetailsList = async() => {
            try {
                const res = await axios.get(`http://localhost:5001/content/getDetails/${id}`)
                setContent(res.data);
            } catch(err) {
                console.log(err);
            }
        }
        getDetailsList()
    },[]);

    function sendData(e){
        e.preventDefault();
        axios.put(`http://localhost:5001/content/update/${id}`, content).then(() => {
            alert("Successfully Updated");
            props.history.push(`/allViewNS`)
            resetForm();
        }).catch((err) => {
            alert("Fild to update");
            alert(err)
        });
    }

    return(
        <div>
            <br/> <br/> <br/> <br/>

            <div className='formStyle'>
                <center><h2>Lession Update</h2></center>
                <div className='form1'>
                    <form onSubmit={sendData} >

                        <label htmlFor="name"><b>Category:</b>{content.category}</label>
                        <br/><br/>                                                          
                      
                        <b><label htmlFor="name">Introduction</label></b><br/>
                        <textarea rows="4" cols="108" className="form-control" id="name" name='introduction'
                            value={content.introduction}
                            onChange={onChange} required>
                        </textarea><br/>

                        <b><label htmlFor="name">Topic</label></b>
                        <input type="text" className="form-control" id="name" name='topic1'
                        value={content.topic1}
                        onChange={onChange}></input>

                        <b><label htmlFor="name">Description</label></b>
                        <input type="text" className="form-control" id="name" name='topic1des'
                        value={content.topic1des}
                        onChange={onChange}></input>

                        <b><label htmlFor="name">Question</label></b>
                        <input type="text" className="form-control" id="name" name='topic1quize'
                        value={content.topic1quize}
                        onChange={onChange}></input>

                        <b><label htmlFor="name">Answer</label></b>
                        <input type="text" className="form-control" id="name" name='topic1answ'
                        value={content.topic1answ}
                        onChange={onChange}></input>

                        
                        
                        <div className='btS'>	
                            <button className='buttonSubmit' type="submit">Update</button>
                        </div>
            </form>

            </div>
            </div>
           
        </div>


    )
}