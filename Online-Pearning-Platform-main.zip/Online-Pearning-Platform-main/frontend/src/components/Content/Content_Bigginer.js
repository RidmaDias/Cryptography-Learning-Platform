import React, { useState, useEffect}  from 'react';
import axios from 'axios';
import './Home.css';

export default function Content_Bigginer() {

    const [BigginerList, setBigginerList] = useState([]);

    useEffect(() => {
        const getDetailsList = async() => {
            try {
                const ListResults = await axios.get(`http://localhost:5001/content/getBigginer`)
                setBigginerList(ListResults.data);
            } catch(err) {
                console.log(err);
            }
        }
        getDetailsList()
    },[]);


    //Collapsible button
    var coll = document.getElementsByClassName("collapsible");
    var i;
    for (i = 0; i < coll.length; i++) {
        coll[i].addEventListener("click", function() {
            this.classList.toggle("active");
            var content = this.nextElementSibling;
            if (content.style.display === "block") {
            content.style.display = "none";
            } else {
            content.style.display = "block";
            }
        }); 
    }

  
    return(
        <div>

            <br/> <br/> <br/> <br/>
            <div class="row">
                <div class="column1" >
                    <div>
                        <u><b><h2>Lessions for Biginners</h2></b><br/></u>
                        <div>
                            {
                            BigginerList.map((bigList, id) => (
                                <div key={id} class="card">
                                    <div class="container">
                                        <h4>Introduction</h4>
                                        <p>{bigList.introduction}</p>
                                        <h4>{bigList.topic1}</h4>
                                        <p>{bigList.topic1des}</p>                          
                                    </div>
                                </div>  
                            ))}
                        </div>
                    </div>
                </div>

                <div class="column2" >
                    <div class="vl"></div>
                </div>

                <div class="column3" >
                    <u><b><h2>Sample Questions & Answers</h2></b><br/></u>
                    <div>
                        {
                        BigginerList.map((bList, id) => (
                            <div key={id} class="card2">
                                <div class="container">
                                    <h3 className='noticeTopic'>{bList.topic1}</h3>
                                    <p>Q : {bList.topic1quize}</p>
                                    <button type="button" class="collapsible"><b>See answer +</b></button>
                                    <div class="content">
                                        <p>{bList.topic1answ}</p>
                                    </div>

                                </div>
                            </div>  
                        ))}               
                    </div>


                </div>
            </div>
            <br/> <br/> <br/> <br/><br/>             
        </div>
    )

}