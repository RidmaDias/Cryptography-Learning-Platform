import React, { useState}  from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import Swal from "sweetalert2";


export default function Content_Create() {

    //const {id} = useParams("");

    const [content, setContent] = useState({
        category:"", introduction:"", 
        topic1:"", topic1des:"", topic1quize:"", topic1answ:"",
        /*topic2:"", topic2des:"", topic2quize:"", topic2answ:"",
        topic3:"", topic3des:"", topic3quize:"", topic3answ:""*/
    });

    const resetForm = () => {
        setContent({category:"", introduction:"", 
        topic1:"", topic1des:"", topic1quize:"", topic1answ:"",
        /*topic2:"", topic2des:"", topic2quize:"", topic2answ:"",
        topic3:"", topic3des:"", topic3quize:"", topic3answ:""*/
    })}

    function sendData(e){
        e.preventDefault();
        axios.post("http://localhost:5001/content/create", content).then(() => {
            Swal.fire({
                title: "Successfully Created",
                icon: 'success',
            });
            resetForm();
        }).catch((err) => {
            Swal.fire({
                title: err,
                icon: 'error',
            });
        });
    }

    const onChange = e => {
        setContent({ ...content, [e.target.name]: e.target.value });
    }

    
    return(
        <div>
             <br/> <br/> <br/> <br/>

            <div className='formStyle'>
            <center><h2>Create Lession</h2></center>
            <div className="form1">
            
            <form onSubmit={sendData} action="/post" method="post">

                <b><label htmlFor="name">Select Category*</label></b>
				<select name='category' value={content.category}
                onChange={onChange} required>
                    <option value="">None</option>
                    <option value="Biginner">Biginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
				</select>

                <b><label htmlFor="name">Introduction*</label></b><br/>
                <textarea rows="4" cols="108" className="form-control" id="name" name='introduction'
                value={content.introduction}
                onChange={onChange} required></textarea><br/>

				<b><label htmlFor="name">Topic</label></b>
                <input type="text" className="form-control" id="name" name='topic1'
                value={content.topic1}
                onChange={onChange}></input>

                <b><label htmlFor="name">Description</label></b>
                <input type="text" className="form-control" id="name" name='topic1des'
                value={content.topic1des}
                onChange={onChange}></input>

                <b><label htmlFor="name">Question</label></b>
                <input type="text" className="form-control" id="name" name='topic1quize'
                value={content.topic1quize}
                onChange={onChange}></input>

                <b><label htmlFor="name">Answer</label></b>
                <input type="text" className="form-control" id="name" name='topic1answ'
                value={content.topic1answ}
                onChange={onChange}></input>                          

                <div className='btS'>	
				<button className='buttonSubmit' type="submit">Create</button>
				</div>
			</form>
		</div>
        </div>

    </div>


    )
}