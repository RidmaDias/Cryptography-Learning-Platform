import React, { useState, useEffect}  from 'react';
import axios from 'axios';
import './Home.css'

export default function Content_Intermediate() {

    const [BigginerList, setBigginerList] = useState([]);

    useEffect(() => {
        const getDetailsList = async() => {
            try {
                const Results = await axios.get(`http://localhost:5001/content/getIntermediate`)
                setBigginerList(Results.data);
            } catch(err) {
                console.log(err);
            }
        }
        getDetailsList()
    },[]);


    //Collapsible button
    var coll = document.getElementsByClassName("collapsible");
    var i;
    for (i = 0; i < coll.length; i++) {
        coll[i].addEventListener("click", function() {
            this.classList.toggle("active");
            var content = this.nextElementSibling;
            if (content.style.display === "block") {
            content.style.display = "none";
            } else {
            content.style.display = "block";
            }
        }); 
    }

  
    return(
        <div>

            <br/> <br/> <br/> <br/>
            <div class="row">
                <div class="column1" >
                    <div>
                        <u><b><h2>Lessions for Intermediates</h2></b><br/></u>
                        <div>
                            {
                            BigginerList.map((listInt, id) => (
                                <div key={id} class="card">
                                    <div class="container">
                                        <h4>Introduction</h4>
                                        <p>{listInt.introduction}</p>
                                        <h4>{listInt.topic1}</h4>
                                        <p>{listInt.topic1des}</p>                          
                                    </div>
                                </div>  
                            ))}
                        </div>
                    </div>
                </div>

                <div class="column2" >
                    <div class="vl"></div>
                </div>

                <div class="column3" >
                    <u><b><h2>Sample Questions & Answers</h2></b><br/></u>
                    <div>
                        {
                        BigginerList.map((interList, id) => (
                            <div key={id} class="card2">
                                <div class="container">
                                    <h3 className='noticeTopic'>{interList.topic1}</h3>
                                    <p>Q : {interList.topic1quize}</p>

                                    <button type="button" class="collapsible"><b>See answer +</b></button>
                                    <div class="content">
                                        <p>{interList.topic1answ}</p>
                                    </div>

                                </div>
                            </div>  
                        ))}               
                    </div>


                </div>
            </div>
            <br/> <br/> <br/> <br/><br/>             
        </div>
    )

}