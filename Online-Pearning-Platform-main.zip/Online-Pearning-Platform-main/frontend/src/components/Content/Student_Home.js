import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css';


import img6 from '../img/img6.png'
import img7 from '../img/img7.png'
import img8 from '../img/img8.png'



const Student_Home = () => {

    return (
        <div className="container my-0 py-3">
            <br/><br/><br/>
            <div className="row">
                <div className="col-12">
                    <div className='col-12'>
                        <center>
                        <h1 className='display-6 text-center mb-4'> <b>ENCRYPTOPOLIS </b></h1></center>
                        <hr className='w-25 mx-auto' />
                    </div>

                </div>
            </div>

            <div class="row">
                <div class="column4" >
                    <a href='/bigginer'> 
                        <img width="300px" src={img7} />                     
                        <h1>Biginners</h1>                  
                    </a>
                </div>

                <div class="column4 abc" >
                    <a href='/interme'> 
                        <img width="310px" src={img6} />                     
                        <h1>Intermediate</h1>                  
                    </a>
                </div>

                <div class="column4 abc" >
                    <a href='/advan'> 
                        <img width="300px" src={img8} />                     
                        <h1>Advanced</h1>                  
                    </a>                 
                </div>			
            </div>


        </div>
    );

}

export default Student_Home;