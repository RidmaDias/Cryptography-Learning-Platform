const mongoose = require('mongoose');

const ContentSchema = new mongoose.Schema({
    category: {
        type: String,
        required: true
    },
    introduction: {
        type: String,
        required: true,
        trim: true
    },
    topic1: {
        type: String,
        required: true
    },
    topic1des: {
        type: String,
        required: true
    },
    topic1quize: {
        type: String,
        required: true
    },
    topic1answ: {
        type: String,
        required: true
    }
});

module.exports = mongoose.model('Content', ContentSchema);