module.exports = {
    mongoURI:'mongodb+srv://sanda:1234@cluster0.rjitr62.mongodb.net/test?retryWrites=true&w=majority'
}


//mongoURI:'mongodb+srv://y3s2:y3s2@cluster0.ptc01e6.mongodb.net/INSTITUTE-MANAGEMENT-SYSTEM?retryWrites=true&w=majority'
//mongoURI:'mongodb+srv://sanda:1234@cluster0.rjitr62.mongodb.net/test?retryWrites=true&w=majority'
