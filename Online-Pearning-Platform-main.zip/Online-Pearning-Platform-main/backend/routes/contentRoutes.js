const express = require("express");
const Content = require('../models/Content');
const router = express.Router();

router.post("/create", (req, res, next) => {
    try{
        const ContentModel = new Content({
            category: req.body.category,
            introduction: req.body.introduction,
            topic1: req.body.topic1,
            topic1des: req.body.topic1des,
            topic1quize: req.body.topic1quize,
            topic1answ: req.body.topic1answ
        });
        ContentModel.save().then(createdContent => {
            res.status(201).json({
                message: "Successfully Submitted",
                ContentId: createdContent._id
            });
        });
    }catch(err){
        return res.status(500).json({ msg: err.message })
    }
});

//view selected detail by id
router.get('/getDetails/:id', async (req, res) => {
  let id = req.params.id;
  Content.findById(id, function (err, detail) {
    res.json(detail);
  });
});


//Update entered details
router.put("/update/:id", (req, res, next) => {
  const ContentModel = ({
    introduction: req.body.introduction,
    topic1: req.body.topic1,
    topic1des: req.body.topic1des,
    topic1quize: req.body.topic1quize,
    topic1answ: req.body.topic1answ
  });
  Content.findOneAndUpdate({ _id: req.params.id }, ContentModel).then(result => {
    console.log(result);
    res.status(200).json({ message: "Successfully Updated" })
  })
});



//get Biginner
router.get("/getBigginer", async (req, res) => {
  try {
    //let categ = req.params.categ;
    const allContent = await Content.find({ category: 'Biginner'});
    res.status(200).json(allContent);
  } catch (err) {
    res.json(err);
  }
})

//get Intermediate
router.get("/getIntermediate", async (req, res) => {
  try {
    //let categ = req.params.categ;
    const allContent = await Content.find({ category: 'Intermediate'});
    res.status(200).json(allContent);
  } catch (err) {
    res.json(err);
  }
})

//get Advanced
router.get("/getAdvanced", async (req, res) => {
  try {
    //let categ = req.params.categ;
    const allContent = await Content.find({ category: 'Advanced'});
    res.status(200).json(allContent);
  } catch (err) {
    res.json(err);
  }
})


//Delete 
router.delete("/delete/:id", async (req, res) => {
  try {
      await Content.findByIdAndDelete(req.params.id)
      res.json({ msg: "Successfully Deleted" })
  } catch (err) {
      return res.status(500).json({ msg: err.message })
  }
})


module.exports = router;